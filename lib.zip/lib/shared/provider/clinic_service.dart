import '../../features/appointment/controller/appointment_provider.dart';
import '../../features/appointment/models/appointment.dart';
import '../../features/patient/controller/patient_provider.dart';
import '../../features/patient/models/patient.dart';

class ClinicService {
  final AppointmentProvider appointmentProvider;
  final PatientProvider patientProvider;

  ClinicService({
    required this.appointmentProvider,
    required this.patientProvider,
  });

  // Add a new appointment and update the patient if necessary
  void addAppointment(Appointment appointment) {
    appointmentProvider.addAppointment(appointment);

    // Check if the patient already exists
    final existingPatient = patientProvider.patients.firstWhere(
      (patient) => patient.id == appointment.patient.id,
      orElse: () => appointment.patient,
    );

    if (existingPatient.id != appointment.patient.id) {
      patientProvider.addPatient(appointment.patient);
    }
  }

  // Update an appointment and its associated patient
  void updateAppointmentAndPatient(Appointment updatedAppointment) {
    appointmentProvider.updateAppointment(updatedAppointment);
    patientProvider.updatePatient(updatedAppointment.patient);
  }

  // Remove an appointment
  void removeAppointment(String appointmentId) {
    appointmentProvider.removeAppointment(appointmentId);
  }

  // Remove an appointment and its associated patient (if no other appointments reference the patient)
  void removeAppointmentAndPatient(String appointmentId) {
    final appointment = appointmentProvider.appointments.firstWhere(
      (appointment) => appointment.id == appointmentId,
    );

    appointmentProvider.removeAppointment(appointmentId);

    // Check if the patient is still referenced in other appointments
    final isPatientReferenced = appointmentProvider.appointments.any(
      (appointment) => appointment.patient.id == appointment.patient.id,
    );

    if (!isPatientReferenced) {
      patientProvider.removePatient(appointment.patient.id);
    }
  }

  // Get all appointments for a specific patient
  List<Appointment> getAppointmentsForPatient(String patientId) {
    return appointmentProvider.appointments
        .where((appointment) => appointment.patient.id == patientId)
        .toList();
  }

  // Get the total number of patients
  int getTotalPatients() {
    return patientProvider.patients.length;
  }

  // Get the total number of appointments
  int getTotalAppointments() {
    return appointmentProvider.appointments.length;
  }

  // Get today's appointments
  List<Appointment> getTodaysAppointments() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    return appointmentProvider.appointments.where((appointment) {
      final appointmentDate = DateTime(
        appointment.dateTime.year,
        appointment.dateTime.month,
        appointment.dateTime.day,
      );
      return appointmentDate == today;
    }).toList();
  }

  // Get cancelled appointments
  List<Appointment> getCancelledAppointments() {
    return appointmentProvider.appointments
        .where((appointment) => appointment.status.toLowerCase() == 'cancelled')
        .toList();
  }

  void addPatient(Patient patient) {
    patientProvider.addPatient(patient);
  }

  void removePatient(String patientId) {
    patientProvider.removePatient(patientId);
  }

  void updatePatient(Patient updatedPatient) {
    // Update the patient in PatientProvider
    patientProvider.updatePatient(updatedPatient);

    // ✅ Ensure all related appointments reflect this update
    appointmentProvider.updateAppointmentPatient(updatedPatient);
  }

}
