import 'package:clinic_appointments/shared/provider/clinic_service.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../appointment/models/appointment.dart';
import '../../appointment/view/appointments_list_view.dart';
import 'stat_card.dart';

class DashboardScreen extends StatelessWidget {
  final int totalPatients;
  final int totalAppointments;
  final int activeAppointmentsToday;
  final int completedAppointments;
  final int cancelledAppointments;
  final List<Appointment> appointments;

  const DashboardScreen({
    super.key,
    required this.totalPatients,
    required this.totalAppointments,
    required this.activeAppointmentsToday,
    required this.completedAppointments,
    required this.cancelledAppointments,
    required this.appointments,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          _buildStatsRow(),
          Expanded(child: Consumer<ClinicService>(
              builder: (context, appointmentsProvider, child) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Text(
                    "Recently Taken Appointments",
                    style: Theme.of(context).textTheme.titleMedium!.copyWith(
                          fontWeight: FontWeight.bold,
                          color: Colors.grey[800],
                        ),
                  ),
                ),
                Expanded(
                  child: AppointmnetsListView(
                      appointments: appointmentsProvider
                          .appointmentProvider.appointments),
                ),
              ],
            );
          })),
        ],
      ),
    );
  }

  /// Builds the row of statistical cards.
  Widget _buildStatsRow() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final bool isSmallScreen = constraints.maxWidth < 600;
        if (isSmallScreen) {
          // For small screens, stack the cards vertically
          return Column(
            children: [
              StatCard(
                title: 'Total Patients',
                value: Provider.of<ClinicService>(context)
                    .getTotalPatients()
                    .toString(),
                icon: Icons.people,
                color: Colors.blue,
              ),
              const SizedBox(height: 16),
              StatCard(
                title: 'Total Appointments',
                value: Provider.of<ClinicService>(context)
                    .getTotalAppointments()
                    .toString(),
                icon: Icons.calendar_today,
                color: Colors.green,
              ),
              const SizedBox(height: 16),
              StatCard(
                title: "Today's Appointments",
                value: Provider.of<ClinicService>(context)
                    .getTodaysAppointments()
                    .length
                    .toString(),
                icon: Icons.event_available,
                color: Colors.orange,
              ),
              const SizedBox(height: 16),
              StatCard(
                title: 'Cancelled Appointments',
                value: Provider.of<ClinicService>(context)
                    .getCancelledAppointments()
                    .length
                    .toString(),
                icon: Icons.cancel,
                color: Colors.red,
              ),
            ],
          );
        } else {
          // For larger screens, display the cards in a row
          return Row(
            children: [
              Expanded(
                child: StatCard(
                  title: 'Total Patients',
                  value: Provider.of<ClinicService>(context)
                      .getTotalPatients()
                      .toString(),
                  icon: Icons.people,
                  color: Colors.blue,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: StatCard(
                  title: 'Total Appointments',
                  value: Provider.of<ClinicService>(context)
                      .getTotalAppointments()
                      .toString(),
                  icon: Icons.calendar_today,
                  color: Colors.green,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: StatCard(
                  title: "Today's Appointments",
                  value: Provider.of<ClinicService>(context)
                      .getTodaysAppointments()
                      .length
                      .toString(),
                  icon: Icons.event_available,
                  color: Colors.orange,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: StatCard(
                  title: 'Cancelled Appointments',
                  value: Provider.of<ClinicService>(context)
                      .getCancelledAppointments()
                      .length
                      .toString(),
                  icon: Icons.cancel,
                  color: Colors.red,
                ),
              ),
            ],
          );
        }
      },
    );
  }
}
