import 'package:clinic_appointments/shared/provider/clinic_service.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../doctor/controller/doctor_provider.dart';
import '../models/appointment.dart';

class EditAppointmentDialog extends StatefulWidget {
  final Appointment appointment;

  const EditAppointmentDialog({
    super.key,
    required this.appointment,
  });

  @override
  State<EditAppointmentDialog> createState() => _EditAppointmentDialogState();
}

class _EditAppointmentDialogState extends State<EditAppointmentDialog> {
  final _formKey = GlobalKey<FormState>();
  late DateTime? _selectedDate;
  late String _status;
  late String _paymentStatus;
  late String _doctorId;

  @override
  void initState() {
    super.initState();
    // Initialize controllers and values with the existing appointment data
    _selectedDate = widget.appointment.dateTime;
    _status = widget.appointment.status;
    _paymentStatus = widget.appointment.paymentStatus;
    _doctorId = widget.appointment.doctor.id;
  }

  // void _showWarning(String message) {
  //   ScaffoldMessenger.of(context).showSnackBar(
  //     SnackBar(
  //       content: Text(message),
  //       backgroundColor: Colors.red,
  //     ),
  //   );
  // }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime now = DateTime.now();
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? now,
      firstDate: now, // Ensure firstDate is not after initialDate
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      // Update the appointment details
      final updatedAppointment = Appointment(
        id: widget.appointment.id,
        patient: widget.appointment.patient,
        dateTime: _selectedDate!,
        status: _status,
        paymentStatus: _paymentStatus,
        doctor: widget.appointment.doctor,
      );

      // Update the patient and appointment in the providers
      Provider.of<ClinicService>(context, listen: false)
          .updateAppointmentAndPatient(updatedAppointment);

      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Update Appointment'),
      content: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            spacing: 16.0,
            children: [
              Text(
                widget.appointment.patient.name,
                style: Theme.of(context).textTheme.titleLarge,
              ),
              ListTile(
                title: Text(
                  _selectedDate == null
                      ? 'Select Appointment Date'
                      : 'Date: ${_selectedDate!.toLocal()}',
                ),
                trailing: const Icon(Icons.calendar_today),
                onTap: () => _selectDate(context),
              ),
              DropdownButtonFormField<String>(
                value: _doctorId,
                decoration: const InputDecoration(
                  labelText: 'Doctor',
                  border: OutlineInputBorder(),
                ),
                items: Provider.of<DoctorProvider>(context, listen: false)
                    .getAllDoctors()
                    .map((doctor) => DropdownMenuItem(
                          value: doctor.id,
                          child: Text(doctor.name),
                        ))
                    .toList(),
                onChanged: (value) {
                  setState(() {
                    _doctorId = value!;
                  });
                },
              ),
              DropdownButtonFormField<String>(
                value: _status,
                decoration: const InputDecoration(
                  labelText: 'Status',
                  border: OutlineInputBorder(),
                ),
                items: ['scheduled', 'completed', 'cancelled']
                    .map((status) => DropdownMenuItem(
                          value: status,
                          child: Text(status),
                        ))
                    .toList(),
                onChanged: (value) {
                  setState(() {
                    _status = value!;
                  });
                },
              ),
              DropdownButtonFormField<String>(
                value: _paymentStatus,
                decoration: const InputDecoration(
                  labelText: 'Payment Status',
                  border: OutlineInputBorder(),
                ),
                items: ['paid', 'unpaid']
                    .map((status) => DropdownMenuItem(
                          value: status,
                          child: Text(status),
                        ))
                    .toList(),
                onChanged: (value) {
                  setState(() {
                    _paymentStatus = value!;
                  });
                },
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: _submitForm,
          child: const Text('Save'),
        ),
      ],
    );
  }
}
