import '../../doctor/models/doctor.dart';
import '../../patient/models/patient.dart';

class Appointment {
  final String id;
  Patient patient;
  final DateTime dateTime;
  final String status; // 'scheduled', 'completed', 'cancelled'
  final String paymentStatus; // 'paid', 'unpaid'
  Doctor doctor;

  Appointment({
    required this.id,
    required this.patient,
    required this.dateTime,
    this.status = 'scheduled',
    this.paymentStatus = 'unpaid',
    required this.doctor,
  });

  factory Appointment.fromJson(Map<String, dynamic> json) {
    return Appointment(
      id: json['id'],
      patient: Patient.fromJson(json['patient']),
      dateTime: DateTime.parse(json['dateTime']),
      doctor: Doctor.fromJson(json['doctor']),
      status: json['status'],
      paymentStatus: json['paymentStatus'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'patient': patient.toJson(),
      'dateTime': dateTime.toIso8601String(),
      'doctor': doctor.toJson(),
      'status': status,
      'paymentStatus': paymentStatus,
    };
  }
}
